/**   @author Isaac Ray Shoebottom (3429069) **/
public class MyFirstJavaProgram {
    public static void main(String[]args) {
        System.out.println("Hello World");
    }
}
