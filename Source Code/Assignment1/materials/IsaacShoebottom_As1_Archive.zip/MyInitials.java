/**   @author Isaac Ray Shoebottom (3429069) **/
public class MyInitials {
    public static void main(String[] args) {
        System.out.println("#########     #### ");
        System.out.println("    #       ##     ");
        System.out.println("    #      #       ");
        System.out.println("    #       ##     ");
        System.out.println("    #         ###  ");
        System.out.println("    #            # ");
        System.out.println("    #            # ");
        System.out.println("    #          ##  ");
        System.out.println("#########  ####    ");
    }
}
