/**
 This class represents a 2D line segment using 2 points.
 @author Natalie Webber
 @author Scott Bateman
*/
public class LineSegment {

  private CartesianPoint pointA;
  private CartesianPoint pointB;
  

  public LineSegment (double x1, double y1, double x2, double y2) {
    pointA = new CartesianPoint (x1, y1);
    pointB = new CartesianPoint (x2, y2);
  }
  
  public LineSegment (CartesianPoint p1, CartesianPoint p2) {
    pointA = p1;
    pointB = p2;
  }
  
  public double getLength () {
    return pointA.distance(pointB);
  }
}
